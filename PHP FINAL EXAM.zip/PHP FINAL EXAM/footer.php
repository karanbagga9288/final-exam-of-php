<footer class="mastfoot mt-auto">
  <div class="inner">
    <p> <h6>Copyright by journal entry club || ONTARIO || CANADA </h6> </p>
  </div>
</footer>
 </div>
 <!--end container-->
</body>
</html>

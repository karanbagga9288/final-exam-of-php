<?php require_once('header.php'); ?>
  <body class="text-center">
    <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
    <?php require_once('navigation.php'); ?>

  <main role="main" class="inner cover">
    <h1 class="cover-heading">Journal Entry</h1>
    <p class="lead">BY- Karan Bagga *200449124*</p>

<p><h3>Information for general entry (canada.entriesJournal.barrie.ca).</h3></p>

  <p>This is a journal entry page where you can access your journals , edit and delete your info provided.<p>

    <p>In order to do so you should be the member of journal club, you can log in to the site and if you are a new user you can register as well</p>
    <p>You can add your records at your journals page; you can edit and delete records after being logged in!</p>

    <p>Thankyou for being at our journals page!</p>

    <p class="lead">
      <a href="add.php" class="btn btn-lg btn-secondary">Create your Journal Entries</a>
      <a href="#" class="btn btn-lg btn-secondary orange">Existing member (LOGIN)</a>
    </p>
  </main>
    <?php require_once('footer.php'); ?>
</div>
</body>
</html>
<!-- end of index.php -->

<header class="masthead mb-auto">
    <div class="inner">
      <h3 class="masthead-brand">Journal Entry|| Make your records better with us..</h3>

      <nav class="nav nav-masthead justify-content-center">
        <a class="nav-link" href="index.php">Home Page</a>
        <a class="nav-link" href="add.php">Your Journals</a>
        <a class="nav-link" href="register.php">Sign Up to our Journal Entry Club, canada</a>
        <a class="nav-link" href="login.php">Login In</a>
        <a class="nav-link" href="logout.php">Log Out</a>
      </nav>
    </div>
  </header>
